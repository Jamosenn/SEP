import React, { useCallback, useState } from 'react';
import {
    Handle,
    Position,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';

import './FieldSelector.css';

export default function FieldSelector({ data }) {

    const [selectedField, setSelectedField] = useState('field 1')

    const onChange = useCallback((event) => {
        console.log(event.target.value);
        setSelectedField(event.target.value)
    }, []);

    const fields = [
        'field 1',
        'field 2',
        'field 3',
    ];

    const stopPropagation = (event) => {
        event.stopPropagation();
    };

    return (
        <>
            <Handle type='source' position={Position.Right} />
            <Handle type='target' position={Position.Left} />
            <div onClick={stopPropagation} className='field-selector-container'>
                <label>Field:</label>
                <select value={selectedField} onChange={onChange}>
                    {fields.map((field) => (
                        <option key={field} value={field}>{field}</option>
                    ))}
                </select>
                
            </div>
        </>
    )
}

