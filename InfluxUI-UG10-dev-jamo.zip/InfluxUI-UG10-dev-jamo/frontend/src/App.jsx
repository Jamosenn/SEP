import React, { useCallback, useRef } from 'react';
import {
  ReactFlow,
  useNodesState,
  useEdgesState,
  Controls,
  reconnectEdge,
  addEdge,
  ReactFlowProvider,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';

import BucketSelector from './BucketSelector'
import FieldSelector from './FieldSelector';
import MeasurementSelector from './MeasurementSelector';
import OutputNode from './OutputNode';

const nodeTypes = {
  bucketSelector: BucketSelector,
  fieldSelector: FieldSelector,
  measurementSelector: MeasurementSelector,
  output: OutputNode,
};


const initialNodes = [];
const initialEdges = [];

export default function App() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const edgeReconnectSuccessful = useRef(true);

  function addNode(nodeType) {
    const newNode = {
      id: (nodes.length + 1).toString(),
      type: nodeType,
      data: { label: `${nodeType} Node` },
      position: { x: 0, y: 0 },
    };
    setNodes((nodes) => [...nodes, newNode]);
  }

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  );

  const onReconnectStart = useCallback(() => {
    edgeReconnectSuccessful.current = false;
  }, [])

  const onReconnect = useCallback((oldEdge, newConnection) => {
    edgeReconnectSuccessful.current = true;
    setEdges((els) => reconnectEdge(oldEdge, newConnection, els));
  })

  const onReconnectEnd = useCallback((_, edge_to_delete) => {
    if (!edgeReconnectSuccessful.current) {
      setEdges((edges) => edges.filter((edge) => edge.id != edge_to_delete.id))
    }
    edgeReconnectSuccessful.current = true;
  }, [])

  return (
    <ReactFlowProvider>
      <div className="SideBar">
        <button onClick={() => addNode('bucketSelector')}>bucket</button>
        <button onClick={() => addNode('fieldSelector')}>field</button>
        <button onClick={() => addNode('measurementSelector')}>measurement</button>
        <button onClick={() => addNode('output')}>output</button>
      </div>
      <div className="Main">
        <div className="Top">
          <div style={{ width: '100%', height: '100%' }}>
              <ReactFlow
                nodes={nodes}
                edges={edges}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onReconnect={onReconnect}
                onReconnectStart={onReconnectStart}
                onReconnectEnd={onReconnectEnd}
                onConnect={onConnect}
                nodeTypes={nodeTypes}
              ><Controls /></ReactFlow>
            </div>
        </div>
        <div className="Bottom">
          <p>Bottom</p>
        </div>
      </div>
    </ReactFlowProvider>
  );
}