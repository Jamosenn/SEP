import React, { useCallback, useState } from 'react';
import {
    Handle,
    Position,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';

import './BucketSelector.css';

export default function BucketSelector({ data }) {

    const [selectedBucket, setSelectedBucket] = useState('bucket 1')

    const onChange = useCallback((event) => {
        console.log(event.target.value);
        setSelectedBucket(event.target.value)
    }, []);

    const buckets = [
        'bucket 1',
        'bucket 2',
        'bucket 3',
    ];

    const stopPropagation = (event) => {
        event.stopPropagation();
    };

    return (
        <>
            <Handle type='source' position={Position.Right} />
            <div onClick={stopPropagation} className='bucket-selector-container'>
                <label>Bucket:</label>
                <select value={selectedBucket} onChange={onChange}>
                    {buckets.map((bucket) => (
                        <option key={bucket} value={bucket}>{bucket}</option>
                    ))}
                </select>
                
            </div>
        </>
    )
}

