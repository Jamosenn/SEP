import React, { useCallback, useState } from 'react';
import {
    Handle,
    Position,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';

import './MeasurementSelector.css';

export default function MeasurementSelector({ data }) {

    const [selectedMeasurement, setSelectedMeasurement] = useState('measurement 1')

    const onChange = useCallback((event) => {
        console.log(event.target.value);
        setSelectedMeasurement(event.target.value)
    }, []);

    const measurements = [
        'measurement 1',
        'measurement 2',
        'measurement 3',
    ];

    const stopPropagation = (event) => {
        event.stopPropagation();
    };

    return (
        <>
            <Handle type='source' position={Position.Right} />
            <Handle type='target' position={Position.Left} />
            <div onClick={stopPropagation} className='measurement-selector-container'>
                <label>Measurement:</label>
                <select value={selectedMeasurement} onChange={onChange}>
                    {measurements.map((measurement) => (
                        <option key={measurement} value={measurement}>{measurement}</option>
                    ))}
                </select>
                
            </div>
        </>
    )
}

