import React, { useCallback, useState } from 'react';
import {
    Handle,
    Position,
} from '@xyflow/react';

import '@xyflow/react/dist/style.css';

import './OutputNode.css';

export default function OutputNode({ data }) {

    const stopPropagation = (event) => {
        event.stopPropagation();
    };

    return (
        <>
            <Handle type='target' position={Position.Left} />
            <div onClick={stopPropagation} className='output-container'>
                <label>Output</label>
            </div>
        </>
    )
}

